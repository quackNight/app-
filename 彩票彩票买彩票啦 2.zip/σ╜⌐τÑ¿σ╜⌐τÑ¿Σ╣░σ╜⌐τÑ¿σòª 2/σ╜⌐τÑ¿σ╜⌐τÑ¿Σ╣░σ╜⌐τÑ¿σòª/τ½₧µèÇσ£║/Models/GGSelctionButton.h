//
//  GGSelctionButton.h
//  幸运转盘- xxx
//
//  Created by 李 on 15/12/22.
//  Copyright © 2015年 李. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GGSelctionButton : UIButton

@end
